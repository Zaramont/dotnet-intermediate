﻿namespace Expressions.Task3.E3SQueryProvider.Models.Entities
{
    public abstract class BaseE3SEntity
    {
    }
}
