﻿namespace Expressions.Task3.E3SQueryProvider.Models.Entities
{
    public class RecognitionEntity
    {
        public string Nomination { get; set; }

        public string Description { get; set; }

        public string RecognitionDate { get; set; }

        public string Points { get; set; }
    }
}
