﻿namespace Expressions.Task3.E3SQueryProvider.Models.Entities
{
    public class SkillsEntity
    {
        public string NativeSpeaker { get; set; }

        public string Expert { get; set; }

        public string Advanced { get; set; }

        public string Intermediate { get; set; }

        public string Novice { get; set; }

        public string Position { get; set; }

        public string Os { get; set; }

        public string Db { get; set; }

        public string Platform { get; set; }

        public string Industry { get; set; }

        public string ProgLang { get; set; }

        public string Language { get; set; }

        public string Other { get; set; }

        public string Primary { get; set; }

        public string Category { get; set; }
    }
}
