﻿namespace Expressions.Task3.E3SQueryProvider.Models.Request.Enums
{
    public enum SortOrder
    {
        Ascending = 1,
        Descending = -1
    }
}
